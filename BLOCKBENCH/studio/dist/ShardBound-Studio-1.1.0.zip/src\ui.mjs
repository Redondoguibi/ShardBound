import { TYPES, EFFECT_TYPES, BODY_PARTS, clone, assertId } from './core.mjs';
import { defaultClipNames } from './templates.mjs';

export function createUI(g, studio, exporter) {
  const actions = [], dialogs = new Set(); let panel;
  const number = (label, value, min = -10000, max = 10000, step = 0.1) => ({ label, type: 'number', value, min, max, step });
  const vector = (label, value) => ({ label, type: 'vector', dimensions: 3, value: value.slice() });
  const input = (label, value) => ({ label, type: 'input', value });
  const select = (label, value, options) => ({ label, type: 'select', value, options });
  const checkbox = (label, value) => ({ label, type: 'checkbox', value });
  const color = (label, value) => ({ label, type: 'color', value });
  const notifyError = error => { g.Blockbench.showMessageBox({ title: 'ShardBound Studio', icon: 'error', message: String(error.message || error) }); return false; };
  const run = fn => { try { const result = fn(); if (result?.catch) return result.catch(notifyError); return result; } catch (e) { return notifyError(e); } };
  function dialog(title, form, confirm, extra = {}) {
    const d = new g.Dialog({ id: 'sbstudio_' + g.guid().replaceAll('-', ''), title, width: 610, form,
      onConfirm(result) {
        for (const [key, field] of Object.entries(form)) if (field.type === 'color') result[key] = result[key].toHexString();
        return run(() => confirm(result));
      }, onButton() { g.setTimeout(() => { dialogs.delete(d); d.delete(); }, 0); }, ...extra }); dialogs.add(d); d.show(); return d;
  }
  const optionsForTargets = () => Object.fromEntries([['', 'Mundo / origem'], ...g.Group.all.map(group => [group.uuid, 'Pasta: ' + group.name]), ...g.Locator.all.map(locator => [locator.uuid, 'Marcador: ' + locator.name])]);
  const model = () => studio.state().models.find(m => m.id === panel.vue.modelId) || studio.state().models[0];
  const effect = () => studio.state().effects.find(e => e.id === panel.vue.effectId) || studio.state().effects[0];
  const resourceOptions = () => Object.fromEntries([...studio.state().effects.map(e => [e.id, `${EFFECT_TYPES[e.kind]} — ${e.id}`]), ...studio.state().sounds.map(s => [s.id, `Som — ${s.id}`])]);
  function newProject() {
    dialog('Novo projeto ShardBound Studio', { type: select('Conteúdo', 'monster', TYPES), id: input('ID namespace:path', 'custom:model'),
      name: input('Nome do projeto', 'Meu modelo'), variant: select('Braços do player', 'wide', { wide: 'Padrão (4 px)', slim: 'Fino (3 px)' }) },
    result => { studio.createProject(result.type, result); panel.vue.modelId = result.id; refresh(); });
  }
  function addModel() {
    const s = studio.state(); dialog('Adicionar modelo independente', { type: select('Conteúdo', 'item', TYPES),
      id: input('ID namespace:path', `${s.id}_${s.models.length + 1}`), name: input('Nome', 'Modelo relacionado') },
      result => { const added = studio.addModel(result.type, result); panel.vue.modelId = added.id; studio.selectModel(added); refresh(); });
  }
  function projectProperties() {
    const s = studio.state(); dialog('Projeto / exportação', { id: input('ID do projeto', s.id), unitsPerMeter: number('Unidades do editor por metro', s.unitsPerMeter, 0.001, 100000),
      sampleRate: number('Amostragem de curvas (FPS)', s.sampleRate, 1, 240, 1), projectileVisual: input('Flecha / projétil visual compartilhado', s.projectileVisual || '') },
      result => { assertId(result.id); if (result.projectileVisual) assertId(result.projectileVisual);
        studio.edit('Studio: propriedades do projeto', () => Object.assign(studio.state(), result, { projectileVisual: result.projectileVisual || null })); });
  }
  function newClip() {
    dialog('Novo clip de animação', { name: input('Nome', defaultClipNames(studio.state().contentType).find(name => !g.Animation.all.some(a => a.name === name)) || 'animation'),
      length: number('Duração (segundos)', 1, 0.01, 1000), loop: select('Reprodução', 'loop', { once: 'Uma vez', loop: 'Repetir', hold: 'Manter último frame' }), fps: number('Frames por segundo', 24, 1, 120, 1) },
      result => studio.createClip(result.name, result.length, result.loop, result.fps));
  }
  function newEffect() {
    dialog('Criar efeito do zero', { kind: select('Tipo de efeito', 'particle', EFFECT_TYPES), id: input('ID namespace:path', `custom:effect_${studio.state().effects.length + 1}`) },
      result => { const e = studio.addEffect(result.kind, result.id); panel.vue.effectId = e.id; editEffect(e); });
  }
  function editEffect(e = effect()) {
    if (!e) return newEffect();
    const textures = Object.fromEntries([['', 'Disco suave gerado pelo Studio'], ...g.Texture.all.map(t => [t.uuid, t.name])]);
    const fields = {
      id: input('ID do efeito', e.id), duration: number('Duração da emissão / efeito (s)', e.duration, 0.001, 3600),
      color: color('Cor inicial', e.color), colorEnd: color('Cor final', e.colorEnd),
      opacity: number('Opacidade inicial', e.opacity, 0, 1, 0.01), opacityEnd: number('Opacidade final', e.opacityEnd, 0, 1, 0.01),
      size: number('Tamanho inicial (unidades do editor)', e.size, 0, 10000), sizeEnd: number('Tamanho final', e.sizeEnd, 0, 10000),
      texture: select('Sprite / textura', e.texture, textures), blend: select('Mistura de cor', e.blend, { alpha: 'Transparência alpha', additive: 'Aditiva' }),
    };
    if (e.kind === 'particle') Object.assign(fields, {
      lifetime: number('Vida de cada partícula (s)', e.lifetime, 0.001, 120), burst: number('Quantidade no disparo', e.burst, 0, 4096, 1),
      rate: number('Partículas por segundo (start)', e.rate, 0, 4096), seed: number('Semente reprodutível', e.seed, 0, 0xffffffff, 1),
      shape: select('Forma de emissão', e.shape, { point: 'Ponto', box: 'Caixa', sphere: 'Esfera', cone: 'Cone' }),
      shapeSize: vector('Dimensões da emissão', e.shapeSize), direction: vector('Direção', e.direction), spread: number('Abertura (graus)', e.spread, 0, 180),
      speed: number('Velocidade (unidades/s)', e.speed, 0, 10000), speedSpread: number('Variação da velocidade', e.speedSpread, 0, 10000),
      gravity: vector('Gravidade / aceleração local do emissor', e.gravity), drag: number('Arrasto', e.drag, 0, 100), follow: checkbox('Seguir o ponto depois de emitir', e.follow),
      rotation: number('Rotação inicial do sprite (graus)', e.rotation, -36000, 36000), angularVelocity: number('Rotação por segundo', e.angularVelocity, -36000, 36000),
      columns: number('Colunas do sprite', e.columns, 1, 256, 1), rows: number('Linhas do sprite', e.rows, 1, 256, 1),
      frames: number('Frames do sprite', e.frames, 1, 65536, 1), fps: number('FPS do sprite', e.fps, 0, 240),
    });
    if (e.kind === 'trail') Object.assign(fields, { trailLength: number('Duração do rastro (s)', e.trailLength, 0.001, 30),
      trailSamples: number('Amostras da faixa', e.trailSamples, 2, 240, 1), width: number('Multiplicador da largura', e.width, 0.001, 10000),
      startOffset: vector('Início da faixa no alvo', e.startOffset), endOffset: vector('Fim da faixa no alvo', e.endOffset) });
    if (e.kind === 'glow') Object.assign(fields, { intensity: number('Intensidade da luz', e.intensity, 0, 10000), distance: number('Alcance da luz', e.distance, 0, 10000) });
    if (e.kind === 'flash') for (const key of ['texture', 'blend', 'size', 'sizeEnd']) delete fields[key];
    dialog(`Editar ${EFFECT_TYPES[e.kind]} — ${e.id}`, fields, values => {
      const changed = studio.updateEffect(e.id, values); panel.vue.effectId = changed.id; refresh();
    });
  }
  function curves(e = effect()) {
    if (!e) throw new Error('Selecione um efeito.');
    const channels = { opacity: 'Opacidade', color: 'Cor' };
    if (e.kind !== 'flash') channels.size = 'Tamanho';
    if (e.kind === 'particle') channels.rotation = 'Rotação (graus)';
    dialog('Curva ao longo da vida', { channel: select('Propriedade', e.kind === 'flash' ? 'opacity' : 'size', channels) },
      ({ channel }) => curveEditor(e.id, channel));
  }
  function curveEditor(id, channel) {
    const e = studio.state().effects.find(e => e.id === id), isColor = channel === 'color';
    const defaults = channel === 'rotation' ? [e.rotation, e.rotation + e.angularVelocity * e.lifetime] : [e[channel], e[channel + 'End']];
    const points = clone(e.curves[channel] || [{ age: 0, value: defaults[0] }, { age: 1, value: defaults[1] }]);
    const d = new g.Dialog({ id: 'sbstudio_curve_' + g.guid(), title: `Curva — ${channel}`, width: 600,
      component: {
        data: () => ({ points, color: isColor }),
        methods: { add() { this.points.push({ age: 0.5, value: this.points[0].value }); }, remove(index) { if (this.points.length > 2) this.points.splice(index, 1); },
          polyline() { const sorted = this.points.slice().sort((a, b) => a.age - b.age), max = Math.max(1, ...sorted.map(p => Number(p.value) || 0));
            return sorted.map(p => `${Math.max(0, Math.min(1, Number(p.age))) * 540},${120 - (Number(p.value) || 0) / max * 110}`).join(' '); } },
        template: `<div class="sbstudio-curve"><p>Idade normalizada: 0 = nascimento; 1 = fim da vida. Os pontos são interpolados em ordem.</p>
          <svg v-if="!color" viewBox="0 0 540 130" style="width:100%;height:130px;background:var(--color-back)"><polyline :points="polyline()" fill="none" stroke="var(--color-accent)" stroke-width="3"/></svg>
          <div v-for="(point,index) in points" :key="index" style="display:flex;gap:8px;margin:6px 0"><label>Idade <input type="number" min="0" max="1" step="0.01" v-model.number="point.age"></label>
          <label>Valor <input v-if="color" type="color" v-model="point.value"><input v-else type="number" step="0.01" v-model.number="point.value"></label><button @click="remove(index)">Remover</button></div>
          <button @click="add">Adicionar ponto</button></div>`,
      }, onConfirm() { return run(() => studio.updateEffect(id, { curves: { ...e.curves, [channel]: clone(d.content_vue.points) } })); },
      onButton() { g.setTimeout(() => { dialogs.delete(d); d.delete(); }, 0); } });
    dialogs.add(d); d.show();
  }
  function eventDialog(existing = null, requestedAnimation = null, requestedTime = g.Timeline.time) {
    const animation = existing ? g.Animation.all.find(a => a.name === existing.clip) : requestedAnimation || g.Animation.selected;
    if (!animation) throw new Error('Crie/selecione um clip na timeline.');
    const resources = resourceOptions(); if (!Object.keys(resources).length) throw new Error('Crie um efeito ou importe um som primeiro.');
    const defaultResource = existing?.resource || effect()?.id || Object.keys(resources)[0];
    dialog(existing ? 'Editar evento da timeline' : 'Efeito / som no frame', {
      resource: select('Recurso', defaultResource, resources), frame: number('Frame', existing?.frame ?? Math.round(requestedTime * animation.snapping), 0, animation.length * animation.snapping, 1),
      action: select('Ação', existing?.action || 'burst', { burst: 'Disparar uma vez', start: 'Iniciar emissão / reprodução', stop: 'Parar instância' }),
      target: select('Pasta / marcador', existing?.target || g.Group.first_selected?.uuid || '', optionsForTargets()),
      offset: vector('Deslocamento local', existing?.offset || [0, 0, 0]), follow: { ...checkbox('Seguir o alvo depois de emitir', existing?.follow || false),
        condition: result => !['trail', 'sound'].includes(studio.state().effects.find(e => e.id === result.resource)?.kind || 'sound') },
      instance: input('Instância (opcional, para start/stop)', existing?.instance || ''),
      volume: number('Volume do som', existing?.volume ?? 1, 0, 1, 0.01), pitch: number('Velocidade do som', existing?.pitch ?? 1, 0.1, 4, 0.1), loop: checkbox('Repetir som até stop / fim do preview', existing?.loop || false),
    }, result => {
      const definition = studio.state().effects.find(e => e.id === result.resource), type = definition?.kind || 'sound';
      const time = result.frame / animation.snapping, values = { ...result, type }; delete values.frame;
      if (type === 'trail' || type === 'sound') values.follow = false;
      if (existing) studio.updateEvent(existing.id, values, time); else studio.addEvent(animation, time, values);
      g.Animator.preview(false); refresh();
    });
  }
  function importAudio() {
    g.Blockbench.import({ resource_id: 'sbstudio_sound', extensions: ['wav', 'ogg', 'mp3'], type: 'Áudio para a timeline', readtype: 'binary' }, files => run(() => {
      if (!files[0]) return;
      const file = files[0], bytes = g.Buffer.from(file.content), extension = file.name.split('.').at(-1).toLowerCase();
      const mime = extension === 'ogg' ? 'audio/ogg' : extension === 'mp3' ? 'audio/mpeg' : 'audio/wav';
      const data = `data:${mime};base64,${bytes.toString('base64')}`;
      dialog('Importar áudio', { id: input('ID namespace:path', 'custom:' + file.name.toLowerCase().replace(/\.[^.]+$/, '').replace(/[^a-z0-9_-]+/g, '_')) },
        result => studio.addSound(result.id, data, file.name));
    }));
  }
  function importSkin() {
    g.Blockbench.import({ resource_id: 'sbstudio_skin', type: 'Skin PNG 64×64', extensions: ['png'], readtype: 'binary' }, files => run(async () => {
      if (!files[0]) return; const data = `data:image/png;base64,${g.Buffer.from(files[0].content).toString('base64')}`;
      await studio.importSkin(data); refresh();
    }));
  }
  function newTexture(sprite = false) {
    const selectedEffect = sprite ? effect() : null;
    if (sprite && !selectedEffect) throw new Error('Selecione o efeito que receberá o sprite.');
    dialog(sprite ? 'Criar sprite para pintar' : 'Criar textura para pintar', { name: input('Nome', sprite ? 'sprite' : 'texture'),
      width: number('Largura (pixels)', 32, 1, 2048, 1), height: number('Altura (pixels)', 32, 1, 2048, 1),
      color: color('Cor inicial', '#ffffff'), alpha: number('Opacidade inicial', sprite ? 0 : 1, 0, 1, 0.01),
      apply: checkbox('Aplicar ao modelo selecionado', !sprite) }, result => {
      const canvas = g.document.createElement('canvas'); canvas.width = result.width; canvas.height = result.height;
      const ctx = canvas.getContext('2d'); ctx.globalAlpha = result.alpha; ctx.fillStyle = result.color; ctx.fillRect(0, 0, result.width, result.height);
      const textures = [], selected = [...g.Cube.selected, ...g.Mesh.selected];
      const elements = result.apply ? (selected.length ? selected : model()?.roots.flatMap(root => studio.find(root)?.getAllChildren?.() || []) || []).filter(e => e.faces) : [];
      studio.edit('Studio: criar textura', () => {
        const texture = new g.Texture({ name: result.name, width: result.width, height: result.height });
        texture.canvas.width = result.width; texture.canvas.height = result.height; texture.ctx.drawImage(canvas, 0, 0);
        texture.fromDataURL(canvas.toDataURL('image/png')).add(); textures.push(texture);
        for (const element of elements) for (const face of Object.values(element.faces)) if (face.texture !== null) face.texture = texture.uuid;
        if (selectedEffect) selectedEffect.texture = texture.uuid;
        texture.select(); g.Modes.options.paint.select();
      }, { textures, elements, bitmap: true });
      refresh();
    });
  }
  function material() {
    const texture = g.Texture.selected; if (!texture) throw new Error('Selecione uma textura no painel Textures.');
    const old = studio.state().materials[texture.uuid] || { alphaMode: 'MASK', alphaCutoff: 0.5, doubleSided: true };
    dialog(`Material — ${texture.name}`, { alphaMode: select('Transparência do modelo', old.alphaMode, { OPAQUE: 'Opaco', MASK: 'Recorte alpha (pixel art)' }),
      alphaCutoff: number('Corte alpha', old.alphaCutoff, 0, 1, 0.01), doubleSided: checkbox('Renderizar os dois lados', old.doubleSided) },
      result => studio.edit('Studio: material', () => { studio.state().materials[texture.uuid] = result; }));
  }
  function bind() {
    const selected = model(); if (!selected) throw new Error('Selecione um modelo.');
    dialog('Encaixar na parte do player', { root: select('Pasta do equipamento', selected.roots[0], Object.fromEntries(selected.roots.map(uuid => [uuid, studio.find(uuid)?.name || uuid]))),
      part: select('Parte do corpo', 'RightArm', Object.fromEntries(BODY_PARTS.map(name => [name, name]))) }, result => studio.bind(selected, result.part, result.root));
  }
  function validate() {
    const report = exporter.validate();
    g.Blockbench.showMessageBox({ title: 'Validação ShardBound Studio', icon: report.valid ? 'check_circle' : 'error',
      message: [report.valid ? 'Projeto válido para exportação do Studio.' : `${report.errors.length} erro(s):`, ...report.errors,
        report.warnings.length ? 'Observações:' : '', ...report.warnings].filter(Boolean).join('\n') }); refresh(); return report;
  }
  async function exportFolder() {
    const report = exporter.validate(); if (!report.valid) return validate();
    const directory = g.Blockbench.pickDirectory({ resource_id: 'sbstudio_export', title: 'Escolha a pasta de destino do pacote Studio' });
    if (!directory) return;
    panel.vue.busy = true;
    try { const result = await exporter.write(directory); g.Blockbench.showMessageBox({ title: 'Pacote exportado', icon: 'check_circle',
      message: `${result.files.length} arquivos em:\n${result.directory}\n\nO conteúdo foi exportado para a fase de integração ao runtime.` }); }
    finally { panel.vue.busy = false; refresh(); }
  }
  const handlers = { newProject, addModel, properties: projectProperties, newClip, newEffect, editEffect: () => editEffect(), curves: () => curves(),
    event: () => eventDialog(), audio: importAudio, skin: importSkin, texture: () => newTexture(false), sprite: () => newTexture(true),
    material, bind, validate, exportFolder, save: () => studio.codec.export(),
    locator: () => dialog('Novo marcador', { name: input('Nome', 'effect_origin') }, result => studio.addLocator(result.name)),
    folder: () => { const groups = []; return studio.edit('Studio: nova pasta', () => { const group = new g.Group({ name: 'Pasta', origin: [0, 0, 0] }).addTo(g.Group.first_selected || studio.find(model()?.roots[0]) || 'root').init(); groups.push(group); group.select(); }, { groups, outliner: true }); },
    modelProperties: () => { const m = model(); if (!m) throw new Error('Selecione um modelo.'); dialog('Propriedades do modelo', { id: input('ID namespace:path', m.id), name: input('Nome', m.name) }, r => { studio.renameModel(m, r.id, r.name); panel.vue.modelId = r.id; }); },
    selectModel: () => { const m = model(); if (m) studio.selectModel(m); },
    removeModel: () => { const m = model(); if (m) g.Blockbench.showMessageBox({ title: 'Remover modelo?', message: m.id, buttons: ['Remover', 'Cancelar'], confirm: 0, cancel: 1 }, answer => { if (answer === 0) run(() => studio.removeModel(m)); }); },
    removeEffect: () => { const e = effect(); if (e) studio.removeEffect(e.id); },
    previewEffect: () => { const e = effect(); if (e) studio.preview.solo(e.id, g.Group.first_selected?.uuid || ''); },
    stopPreview: () => studio.preview.stopSolo(),
    layer: () => { const layers = studio.state().models.flatMap(m => m.player?.layers || []).map(studio.find).filter(Boolean); studio.setSkinLayers(!layers.every(e => e.visibility)); },
  };
  const ids = {};
  for (const [name, title, icon] of [
    ['newProject', 'Novo projeto Studio', 'add_box'], ['addModel', 'Adicionar modelo independente', 'library_add'], ['properties', 'Propriedades do projeto', 'settings'],
    ['folder', 'Nova pasta animável', 'create_new_folder'], ['newClip', 'Novo clip', 'movie'], ['locator', 'Novo marcador', 'pin_drop'],
    ['newEffect', 'Criar efeito do zero', 'auto_awesome'], ['event', 'Efeito / som no frame', 'add'], ['audio', 'Importar som', 'audio_file'],
    ['skin', 'Importar skin 64×64', 'image'], ['texture', 'Criar textura', 'palette'], ['sprite', 'Criar sprite', 'brush'],
    ['material', 'Material da textura', 'texture'], ['bind', 'Encaixar equipamento', 'pan_tool'],
    ['validate', 'Validar projeto', 'fact_check'], ['save', 'Salvar projeto Studio', 'save'], ['exportFolder', 'Exportar pacote GLB + efeitos', 'folder_zip'],
  ]) { const action = new g.Action('sbstudio_' + name, { name: title, icon, condition: name === 'newProject' ? () => true : studio.isStudio,
      click: () => run(handlers[name]) }); actions.push(action); ids[name] = action.id; }
  g.MenuBar.addAction({ name: 'ShardBound Studio', id: 'sbstudio_menu', icon: 'auto_awesome', children: Object.values(ids) }, 'tools');
  g.MenuBar.addAction(ids.newProject, 'file.new');
  panel = new g.Panel('shardbound_studio', { name: 'ShardBound Studio', icon: 'auto_awesome', condition: studio.isStudio,
    default_position: { slot: 'right_bar', height: 500 }, growable: true, resizable: true, min_height: 200,
    component: {
      data: () => ({ models: [], effects: [], sounds: [], events: [], modelId: '', effectId: '', busy: false, projectId: '', clip: '', errorCount: 0, previewError: '' }),
      methods: { action(name) { return run(handlers[name]); }, select() { run(handlers.selectModel); },
        editEvent(id) { const event = studio.events().find(e => e.id === id); if (event) run(() => eventDialog(event)); },
        removeEvent(id) { run(() => studio.removeEvent(id)); }, removeSound(id) { run(() => studio.removeSound(id)); } },
      template: `<div class="sbstudio-panel" style="padding:8px;overflow:auto;height:100%">
        <p><b>{{projectId}}</b></p><div class="sbstudio-buttons"><button @click="action('properties')">Projeto</button><button @click="action('save')">Salvar .sbstudio</button></div>
        <h3>Modelos independentes</h3><select v-model="modelId" @change="select" style="width:100%"><option v-for="m in models" :key="m.id" :value="m.id">{{m.name}} — {{m.id}}</option></select>
        <div class="sbstudio-buttons"><button @click="action('addModel')">Adicionar modelo</button><button @click="action('modelProperties')">Propriedades</button><button @click="action('removeModel')">Remover</button></div>
        <div class="sbstudio-buttons"><button @click="action('folder')">Nova pasta</button><button @click="action('bind')">Encaixar no player</button><button @click="action('locator')">Marcador</button></div>
        <h3>Texturas / skins</h3><div class="sbstudio-buttons"><button @click="action('texture')">Criar textura</button><button @click="action('material')">Material</button><button @click="action('skin')">Importar skin</button><button @click="action('layer')">Camadas da skin</button></div>
        <h3>Animação e eventos</h3><p>{{clip || 'Selecione/crie um clip na timeline nativa.'}}</p><div class="sbstudio-buttons"><button @click="action('newClip')">Novo clip</button><button @click="action('event')">Efeito / som no frame</button></div>
        <div v-for="event in events" :key="event.id" class="sbstudio-event"><span>F{{event.frame}} · {{event.type}} · {{event.action}}<br>{{event.resource}}</span><button @click="editEvent(event.id)">Editar</button><button @click="removeEvent(event.id)">×</button></div>
        <h3>Efeitos do zero</h3><select v-model="effectId" style="width:100%"><option v-for="e in effects" :value="e.id" :key="e.id">{{e.kind}} — {{e.id}}</option></select>
        <div class="sbstudio-buttons"><button @click="action('newEffect')">Novo efeito</button><button @click="action('editEffect')">Parâmetros</button><button @click="action('curves')">Curvas da vida</button><button @click="action('sprite')">Pintar sprite</button><button @click="action('removeEffect')">Remover</button></div>
        <div class="sbstudio-buttons"><button @click="action('previewEffect')">Pré-visualizar efeito</button><button @click="action('stopPreview')">Voltar à timeline</button></div>
        <h3>Sons sincronizados</h3><button @click="action('audio')">Importar WAV / OGG / MP3</button><div v-for="sound in sounds" :key="sound.id" class="sbstudio-event"><span>{{sound.id}}</span><button @click="removeSound(sound.id)">×</button></div>
        <p v-if="previewError" style="color:var(--color-error)">{{previewError}}</p>
        <h3>Validar e exportar</h3><div class="sbstudio-buttons"><button @click="action('validate')">Validar ({{errorCount}} erros)</button><button :disabled="busy" @click="action('exportFolder')">{{busy ? 'Exportando…' : 'Exportar GLB + arquivos auxiliares'}}</button></div>
      </div>`,
    } });
  const css = g.Blockbench.addCSS('.sbstudio-panel h3{margin:12px 0 5px}.sbstudio-buttons{display:flex;gap:4px;flex-wrap:wrap;margin:5px 0}.sbstudio-panel button{padding:3px 7px}.sbstudio-event{display:flex;gap:4px;align-items:center;padding:5px 0;border-bottom:1px solid var(--color-border)}.sbstudio-event span{flex:1;overflow-wrap:anywhere}');
  function refresh() {
    if (!studio.isStudio() || !panel?.vue) return;
    const s = studio.state(), vm = panel.vue; vm.models = s.models; vm.effects = s.effects; vm.sounds = s.sounds; vm.events = studio.events();
    vm.projectId = s.id; vm.clip = g.Animation.selected?.name || ''; vm.errorCount = exporter.validate().errors.length;
    if (!s.models.some(m => m.id === vm.modelId)) vm.modelId = s.models[0]?.id || '';
    if (!s.effects.some(e => e.id === vm.effectId)) vm.effectId = s.effects[0]?.id || '';
  }
  const boneLabel = g.Panels.bone?.handle?.querySelector('span'), originalBoneLabel = boneLabel?.textContent;
  const updateVocabulary = () => { if (boneLabel) boneLabel.textContent = studio.isStudio() ? 'Pasta / pivô' : originalBoneLabel; };
  const updatePreviewError = () => { if (studio.isStudio() && panel.vue) panel.vue.previewError = studio.preview.lastError; };
  g.Blockbench.on('render_frame', updatePreviewError);
  g.Blockbench.on('select_project', updateVocabulary); updateVocabulary();
  studio.onRequestEvent = (animation, time) => run(() => eventDialog(null, animation, time));
  studio.onRefresh = refresh; refresh();
  return { panel, handlers, refresh, dispose() { studio.onRefresh = studio.onRequestEvent = null; g.Blockbench.removeListener('select_project', updateVocabulary); g.Blockbench.removeListener('render_frame', updatePreviewError); if (boneLabel) boneLabel.textContent = originalBoneLabel; for (const d of dialogs) { if (g.Dialog.stack.includes(d)) d.hide(); d.delete(); } dialogs.clear(); panel.delete(); css.delete();
    g.MenuBar.removeAction('tools.sbstudio_menu'); g.MenuBar.removeAction('file.new.' + ids.newProject); actions.forEach(a => a.delete()); } };
}
