# ShardBound Studio 1.1.0

Plugin **novo e independente** para **Blockbench Desktop 5.2.2**. Reúne modelos, skins, animações por pastas, partículas criadas do zero, rastros, flashes, brilho/luz e sons na mesma timeline. Não depende do MCP, de serviços externos ou do plugin antigo.

## Instalar

1. Abra o **Blockbench 5.2.2**.
2. Abra **Arquivo → Plugins**. Se o menu não estiver visível, pressione **F3**, procure **Plugins** e abra o gerenciador.
3. Clique no botão de **carregar plugin de arquivo** (ícone de arquivo/código; em inglês, *Load Plugin from File*).
4. Selecione **`dist/shardbound_studio.js`** e confirme o carregamento local.
5. Abra **Arquivo → Novo → Novo projeto Studio**, ou **Ferramentas → ShardBound Studio → Novo projeto Studio**.

O arquivo JavaScript já está compilado. **Não é necessário instalar Node.js, npm, servidor ou MCP para usar o plugin.** Mantenha-o numa pasta permanente: o Blockbench lembra sua localização. Para atualizar, substitua o arquivo e recarregue o plugin no gerenciador. Salve seus projetos antes de atualizar/desativar.

Ao exportar uma pasta, o Blockbench 5.2.2 pode pedir **Plugin Permission** para acessar a pasta escolhida. **Allow once** permite esta exportação; **Always allow for this plugin** lembra essa pasta. O plugin solicita acesso ao destino da exportação. Importação de skins/áudio e salvamento do projeto usam os seletores nativos.

## Usar pelo ChatGPT ou Codex

Instale também a **ShardBound Bridge 0.5+** e selecione o plugin de conta **ShardBound Blockbench**. A integração fornece 34 ferramentas, incluindo toda a autoria Studio, captura, MTools e exportação do pacote completo. Siga o [guia de conexão do Studio](../bridge/STUDIO-COMPATIBILITY.md). O Studio continua funcionando sozinho sem MCP. Projetos da versão 1.0 mantêm o contrato v1.

## Começar

- **Player / skin:** escolha braços padrão ou finos. O projeto possui seis pastas corporais, textura PNG 64×64 e camadas externas. Pinte no modo **Pintar**, use **Importar skin** ou **Camadas da skin**. Crie as animações gerais no mesmo projeto.
- **Armas corpo a corpo / longa distância:** o player neutro aparece como referência. Modele dentro da pasta do equipamento; use **Encaixar no player** e ajuste cubos, pivôs e transformações com as ferramentas nativas. Anime também as pastas do player: pernas, tronco, cabeça e braços permanecem disponíveis na mesma timeline. A referência usa geometria/textura próprias.
- **Armadura:** as seis pastas de sobreposição já ficam vinculadas às partes do player. Crie seus cubos dentro delas e ajuste a espessura/posição. Elas acompanham o corpo; animações próprias são opcionais.
- **Monstro:** monte livremente suas pastas, pivôs e hierarquia. Não existe anatomia obrigatória.
- **Item / bloco de cenário:** modele, pinte e anime com as ferramentas nativas. O bloco começa como cubo de 16 unidades e serve à composição visual de cenários.
- **Vários modelos:** **Adicionar modelo independente** cria outro objeto com ID próprio no mesmo projeto. Cada modelo gera seu GLB. Pastas internas de um modelo continuam parte daquele objeto.

IDs usam `namespace:path`, por exemplo `meumod:armas/espada`. O painel **ShardBound Studio** reúne os comandos; os mesmos comandos estão em **Ferramentas → ShardBound Studio**. **Nova pasta** cria um grupo animável; **Marcador** cria uma origem de efeito que acompanha a pasta selecionada. Cubos, malhas, UV, pintura e keyframes de posição/rotação/escala são editados nos modos nativos.

Para salvar a skin como PNG separado, use **Salvar como** no menu de contexto da textura no painel nativo **Texturas**. O Studio não converte automaticamente projetos de outros formatos; crie um projeto Studio e importe/copie sua geometria para as pastas dos modelos declarados.

## Efeitos e sons na timeline

1. Crie/selecione um **Novo clip**, com nome, duração, loop e FPS próprios.
2. Clique em **Novo efeito**, escolha partículas, rastro, flash ou brilho/luz e dê um ID.
3. Edite os parâmetros. Para partículas, configure emissão, forma, vida, quantidade, velocidade, gravidade local, arrasto, tamanho, cor, opacidade, rotação e atlas. **Curvas da vida** edita visualmente os pontos dessas propriedades.
4. **Pintar sprite** cria uma imagem editável no modo Pintar. Também é possível importar PNG pelo painel nativo de texturas e escolhê-lo nos parâmetros do efeito. O sprite inicial transparente é uma tela para pintura, não um efeito pronto.
5. **Importar WAV / OGG / MP3** incorpora áudio próprio ao projeto. Arquivos inválidos são recusados após decodificação real.
6. Na timeline, use **Efeito / som no frame**, ou o **+** da trilha **ShardBound: efeitos e sons**. Escolha recurso, frame, pasta/marcador, deslocamento e ação. Para sons, configure volume, pitch e repetição.
7. **Disparar uma vez** emite um burst; **Iniciar** cria emissão/reprodução; **Parar** encerra a instância. Use o mesmo nome de instância para seu par start/stop. **Seguir o alvo** mantém o efeito vinculado; desmarcado, o nascimento fica no mundo. Rastros registram a trajetória em espaço de mundo.
8. Reproduza a timeline para conferir movimento, VFX e áudio. Arrastar o tempo recalcula os efeitos visualmente; não toca sons a cada arraste. **Pré-visualizar efeito** permite revisar um efeito isolado; **Voltar à timeline** encerra esse preview.

Os eventos aparecem como keyframes nativos e na lista do painel. Eventos no mesmo frame mantêm ordem estável. **Editar** move um evento individual; arrastar o keyframe nativo move todos os eventos daquele keyframe. Não há formulários de dano, IA ou combate.

## Salvar e exportar

**Salvar .sbstudio** preserva geometria, UV, texturas, clips, áudio e eventos num projeto editável. Reabra por **Arquivo → Abrir modelo**. O formato usa o serializador de projetos do Blockbench e metadados Studio versionados. O salvamento nativo `.bbmodel` também preserva esses dados quando o plugin está carregado; prefira o botão Studio para a extensão própria.

**Validar** aponta problemas concretos: texturas ausentes, UV inválido, referências removidas, IDs repetidos, parâmetros inválidos, clips incompatíveis e geometria fora de modelos declarados.

**Exportar GLB + arquivos auxiliares** solicita a pasta de destino e cria um novo pacote:

```text
meumod_espada/
├── models/meumod/espada.glb
├── effects/meumod/faiscas.png
├── audio/meumod/golpe.wav
├── studio.manifest.json
├── studio.effects.json
├── studio.events.json
└── studio.player-animations.json
```

O GLB contém texturas incorporadas, pastas como nós rígidos e animações. A geometria do player de referência não é duplicada no GLB da arma. Os canais corporais e o movimento da raiz ficam registrados no arquivo de animações do player. Os auxiliares registram efeitos, sons, attachments e ordem dos eventos. Pacotes existentes recebem uma nova pasta com sufixo; scripts e mods não são sobrescritos.

Armas ranged começam com a referência visual compartilhada **`core:arrow`**, configurável em **Projeto**. Isso é um ID exportado para futura resolução por mods/runtime, não uma implementação de projétil de gameplay.

## Exemplos, contratos e verificação

- [Exemplos originais](examples/README.md)
- [Contratos de exportação e renderização](docs/CONTRATOS.md)
- [Cobertura dos requisitos e limites reais](docs/IMPLEMENTACAO.md)
- [Testes e reprodução](docs/TESTES.md)

**Fase A, editor:** as ferramentas e a exportação funcionam no Blockbench. **Fase B, jogo:** o carregamento dos auxiliares, reprodução de clips/equipamentos/VFX/sons e a comparação de aparência idêntica ao jogo continuam para a integração do runtime, conforme a especificação. A existência de um GLB válido não significa que o runtime atual já execute suas animações.

## Desenvolvimento

Requer Node.js 22 ou superior. Em `BLOCKBENCH/studio`:

```powershell
npm ci
npm run build
npm test
npm run test:blockbench
npm run package
```

O teste de integração abre uma instância separada do Blockbench 5.2.2 com perfil temporário em `.local/e2e/`. Não utiliza nem altera o modelo aberto na instância pessoal. `BLOCKBENCH_EXE` permite indicar outro caminho para o executável 5.2.2. O build gera um único arquivo e não exige dependências durante o uso.
